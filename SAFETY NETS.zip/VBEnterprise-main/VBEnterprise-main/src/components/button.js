import Button from 'react-bootstrap/Button';
import "./butto.css";
function TypesExample() {
  return (
    <>
    <div className="py-5">  <Button variant="dark" size="lg" href='/services' className='butto1'>All Services</Button>
    </div>
    </>
  );
}

export default TypesExample;