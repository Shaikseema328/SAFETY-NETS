import icon1 from "../assests/Frame.png"
import icon2 from "../assests/Vector.png"
import icon3 from "../assests/Frame (2).png"

const Sdata=[
    {
        icon1:icon1,
        heading1:"Quality",
        heading2:"We use high quality nylon nets for strong and long lasting safety nets."
        },
    {
            icon1:icon2,
            heading1:"Safety",
            heading2:"Safeguarding Your World with Unmatched Excellence."
            },
    {
    icon1:icon3,
    heading1:"Timely Work",
    heading2:"Excellence Delivered Right on Time."
    },
]

export default Sdata